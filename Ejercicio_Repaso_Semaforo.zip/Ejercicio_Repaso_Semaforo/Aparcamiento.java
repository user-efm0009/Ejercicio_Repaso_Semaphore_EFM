package Ejercicio_Repaso_Semaforo;

import java.util.concurrent.Semaphore;

public class Aparcamiento {

    // ATRIBUTOS
    private Semaphore semaforo;
    private int plazas;

    // CONSTRUCTOR
    public Aparcamiento(int plazasDisponibles) {

        semaforo = new Semaphore(plazasDisponibles);

    }

    // METODO - ENTRAR

    public void entrar (String Coche) {

        try {

            System.out.println(Coche + " esta esperando...");
            semaforo.acquire(); // SIRVE PARA IMPLEMENTARLO (EL COCHE AL APARCAMIENTO)

            // SYNCHRONIZED (THIS) SIRVE PARA MANEJAR LOS CONTADORES PARA CUANDO AUMENTE O DISMINUYA
            synchronized (this) {

                plazas++; // INCREMENTACIÓN AUTOMÁTICA DE 1 EN 1
                System.out.println(Coche + " ha entrado. Plazas ocupadas: " + plazas);

            }

        } catch (InterruptedException e) {

            System.out.println("Se ha producido un error al intentar la entrada del " + Coche);
            Thread.currentThread().interrupt(); // MARCAR QUE EL HILO ACTUAL ESTA INTERRUMPIDO

        }

    }

    // METODO - SALIR

    public void salir (String Coche) {

        semaforo.release(); // SIRVE PARA LIBERAR (EL COCHE DEL APARCAMIENTO, PORQUE NO SIEMPRE VA A ESTAR EN EL APARCAMIENTO)

        synchronized (this) {

            plazas--; // DISMINUCION AUTOMATICA DE 1 EN 1
            System.out.println(Coche + " ha salido.... Plazas ocupadas: " + plazas);

        }

    }

}
