package Ejercicio_Repaso_Semaforo;

public class PrincipalParking {
    public static void main(String[] args) {

        Aparcamiento aparcamiento = new Aparcamiento(3); // PLAZAS DE APARCAMIENTO QUE TENDREMOS DISPONIBLES EN NUESTRO PARKING

        // BUCLE FOR - PARA ENUMERAR A CADA COCHE QUE VAYA ESPERANDO, ENTRANDO Y SALIENDO DEL PARKING

        for (int i = 1; i <= 7; i++) {

            String coche = "Coche-" + i; // PARA ENUMERAR A CADA COCHE Y DIFERENCIARLOS
            Thread hilo = new Thread (new Coche(aparcamiento, coche)); // CREAMOS EL HILO
            hilo.start(); // INICIA EL HILO

        }

    }
}
