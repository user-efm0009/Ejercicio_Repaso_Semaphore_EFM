package Ejercicio_Repaso_Semaforo;

import java.util.Random;

public class Coche implements Runnable {

    // ATRIBUTOS PRIVADOS
    private final Aparcamiento aparcamiento;
    private final String nombre;

    // CONSTRUCTOR
    public Coche(Aparcamiento aparcamiento, String nombre) {

        this.aparcamiento = aparcamiento;
        this.nombre = nombre;

    }

    @Override
    public void run() {

        aparcamiento.entrar(nombre); // COGEMOS EL METODO DE ENTRAR EN LA CLASE APARCAMIENTO

        try {

            int tiempoAparcado = new Random().nextInt(4000); // ENTRE 1 Y 4 SEGUNDOS, SE ALMACENA EN UNA VARIABLE
            Thread.sleep(tiempoAparcado); // EL COCHE ESTA APARCADO, CON EL METODO SLEEP LLAMANDO A LA VARIABLE ANTERIOR QUE ALMACENA EL RANDOM

        } catch (InterruptedException e) {

            e.printStackTrace();

        }

        aparcamiento.salir(nombre); // COGEMOS EL METODO DE SALIR EN LA CLASE APARCAMIENTO

    }

}